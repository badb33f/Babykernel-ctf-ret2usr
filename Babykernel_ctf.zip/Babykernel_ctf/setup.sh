#!/bin/bash
gcc exploit.c -o exploit -static $1
mv ./exploit ./initramfs
cd initramfs
find . -print0 \
| cpio --null -ov --format=newc \
| gzip -9 > core.cpio
mv ./core.cpio ../

